var setBuildingSimple = function(blockType, buildingType, overrides) {
    blockType.buildType = prov(() => new JavaAdapter(buildingType, overrides, blockType));
}
const hx = extend(CoreBlock, "hx", {
    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
    canPlaceOn(tile, team) { return true; },
    placeBegan(tile, previous) {},
    beforePlaceBegan(tile, previous) {},

    drawPlace(x, y, rotation, valid) {},
});
setBuildingSimple(hx, CoreBlock.CoreBuild, {
});
hx.unitType = UnitTypes.oct;