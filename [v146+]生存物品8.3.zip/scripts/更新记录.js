//xvxshenhun@qq.com，使用标注来源（禁止删除注释）

StatusEffects.burning.color = Pal.lightFlame;
StatusEffects.freezing.color = Liquids.cryofluid.color;
StatusEffects.wet.color = Liquids.water.color;
StatusEffects.tarred.color = Liquids.oil.color;
StatusEffects.melting.color = Liquids.slag.color;
StatusEffects.shocked.color = Pal.lancerLaser;
StatusEffects.boss.color = Pal.health;

Blocks.illuminator.buildVisibility = BuildVisibility.shown;

this.global.SOUNDS = {};
this.global.UNITS = {};
this.global.WEATHERS = {};
this.global.COLORS = {};
this.global.WALLS = {};
this.global.EFFECTS = {};
this.global.STATUSES = {};
this.global.TURRETS = {};